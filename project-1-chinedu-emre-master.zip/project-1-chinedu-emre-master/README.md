[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/EMUM20dE)
# Project 1

### Timeline
 - Data exploration: Thursday, February 1 *in class*
 - Final paper: Tuesday, February 13 *via gitHub*

### Repo contents
 - `doc`: Detailed project description
 - `data`: Data and data documentation


### *Notes*
 - Keep your repo organized (e.g. add a `src` folder for code)
 - Commit and push often (your commit history is interpreted as your working history)

